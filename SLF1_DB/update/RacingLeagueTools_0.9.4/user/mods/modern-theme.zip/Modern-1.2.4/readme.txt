Modern theme v1.0

For calendar:
You need to divide by two your number of event and set this number in theme option under
Second Calendar Events In Column
so for 22 event you set 11

For Lineup

You need to set ReserveDriverMax to : (Number of reserve driver /2 round it up to next even number)

ex you have 5 reserve drivers so Reserve Driver Max will be 3

If you don't use reserve you need to set this number to 0


****
I use Real Name, Name field and Race Number in the database 

Use Real name as Firstname and Name as LastName

So Real name = Max  **use a space at the end 
and Name = Verstapen 

Thanks to 

Sirotkin for making this !

Kaac for support !
